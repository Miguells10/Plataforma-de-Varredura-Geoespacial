import requests
import pandas as pd
import geopandas as gpd
from shapely.geometry import LineString, box


# Mantém sua função antiga de subestações...
def buscar_subestacoes_osm(cidade="Aracaju"):
    # ... (seu código existente fica aqui) ...
    pass


def buscar_ruas_box(lat_min, lon_min, lat_max, lon_max):
    """
    Baixa as ruas (highways) dentro de um Bounding Box para fazer a filtragem.
    """
    overpass_url = "http://overpass-api.de/api/interpreter"

    # Busca ruas primárias, secundárias e residenciais
    query = f"""
    [out:json][timeout:25];
    (
      way["highway"]({lat_min},{lon_min},{lat_max},{lon_max});
    );
    out geom;
    """

    try:
        response = requests.get(overpass_url, params={'data': query}, timeout=30)
        data = response.json()

        ruas = []
        for element in data['elements']:
            if 'geometry' in element:
                coords = [(pt['lon'], pt['lat']) for pt in element['geometry']]
                if len(coords) > 1:
                    ruas.append(LineString(coords))

        if ruas:
            # Retorna um GeoDataFrame
            return gpd.GeoDataFrame(geometry=ruas, crs="EPSG:4326")

    except Exception as e:
        print(f"Erro ao baixar ruas: {e}")

    return gpd.GeoDataFrame()


def filtrar_pontos_em_ruas(lista_pontos, raio_busca=0.005):
    """
    Recebe a lista de hexágonos e remove aqueles que tocam em ruas.
    """
    if not lista_pontos: return []

    # 1. Cria GeoDataFrame dos Pontos (Hexágonos)
    df_pontos = pd.DataFrame(lista_pontos)
    gdf_pontos = gpd.GeoDataFrame(
        df_pontos,
        geometry=gpd.points_from_xy(df_pontos.longitude, df_pontos.latitude),
        crs="EPSG:4326"
    )

    # 2. Baixa as Ruas daquela região (Bounding Box)
    bounds = gdf_pontos.total_bounds  # [minx, miny, maxx, maxy]
    gdf_ruas = buscar_ruas_box(bounds[1], bounds[0], bounds[3], bounds[2])

    if gdf_ruas.empty:
        return lista_pontos  # Se não achou ruas, retorna tudo (melhor pecar pelo excesso)

    # 3. SPATIAL JOIN (A mágica do Matt Forrest)
    # Vamos dar um buffer nas ruas (ex: 10m de largura) para garantir
    # Convertemos para metros (EPSG:3857) para buffer preciso
    gdf_ruas_metro = gdf_ruas.to_crs(epsg=3857)
    gdf_ruas_buffer = gdf_ruas_metro.buffer(10).to_crs(epsg=4326)  # 10 metros de "zona de rua"

    gdf_zonas_rua = gpd.GeoDataFrame(geometry=gdf_ruas_buffer, crs="EPSG:4326")

    # sjoin: Encontra pontos que INTERSECTAM as ruas
    # op='disjoint' não é nativo do sjoin direto de forma simples, então fazemos o inverso:
    # Achamos quem TOCA e removemos.

    pontos_nas_ruas = gpd.sjoin(gdf_pontos, gdf_zonas_rua, how="inner", predicate="intersects")

    # Filtra: Mantém apenas os que NÃO estão no index dos pontos de rua
    gdf_limpo = gdf_pontos[~gdf_pontos.index.isin(pontos_nas_ruas.index)]

    # Reconstrói a lista de dicionários
    return gdf_limpo.drop(columns='geometry').to_dict('records')